create table admin_db
(
    id             int auto_increment
        primary key,
    admin_id       varchar(20) not null,
    admin_password longtext    not null,
    name           varchar(20) not null,
    tell_number    varchar(20) not null,
    bank           varchar(45) not null
);

create table product_db
(
    id           int auto_increment
        primary key,
    pd_name      varchar(45)    not null,
    pd_price     int            not null,
    pd_amount    varchar(45)    not null,
    pd_image_url varchar(200)   not null,
    pd_date      datetime       not null,
    pd_content   blob default 0 null
);

create table user_db
(
    id            int auto_increment
        primary key,
    user_id       varchar(20)             not null,
    user_password longtext                not null,
    name          varchar(20)             null,
    tell_number   varchar(20)             not null,
    address       varchar(45) default '0' null
);

create table address_db
(
    id          int auto_increment
        primary key,
    user_id     int         not null,
    tell_number varchar(20) not null,
    address     varchar(45) not null,
    constraint address_db_user_db_id_fk
        foreign key (user_id) references user_db (id)
            on update cascade on delete cascade
)
    charset = latin1;

create table order_db
(
    id          int auto_increment
        primary key,
    user_id     int      not null,
    order_date  datetime not null,
    total_price int      not null,
    constraint order_db_user_db_id_fk
        foreign key (user_id) references user_db (id)
            on update cascade on delete cascade
);

create table cart
(
    order_id      int not null,
    order_user_id int not null,
    pd_id         int null,
    constraint cart_order_db_id_fk
        foreign key (order_id) references order_db (id)
            on update cascade on delete cascade,
    constraint cart_order_db_user_id_fk
        foreign key (order_user_id) references order_db (user_id)
            on update cascade on delete cascade,
    constraint cart_product_db_id_fk
        foreign key (pd_id) references product_db (id)
            on update cascade on delete cascade
);

create table deliveries_db
(
    id              int auto_increment
        primary key,
    address_id      int not null,
    address_user_id int not null,
    order_id        int not null,
    order_user_id   int not null,
    constraint deliveries_db_address_db_id_fk
        foreign key (address_id) references address_db (id)
            on update cascade on delete cascade,
    constraint deliveries_db_address_db_user_id_fk
        foreign key (address_user_id) references address_db (user_id)
            on update cascade on delete cascade,
    constraint deliveries_db_order_db_id_fk
        foreign key (order_id) references order_db (id)
            on update cascade on delete cascade,
    constraint deliveries_db_order_db_user_id_fk
        foreign key (order_user_id) references order_db (user_id)
            on update cascade on delete cascade
);

create table purchase_db
(
    id            int auto_increment
        primary key,
    purchase_date datetime not null,
    user_id       int      not null,
    order_id      int      null,
    order_user_id int      not null,
    constraint purchase_db_order_db_id_fk
        foreign key (order_id) references order_db (id)
            on update cascade on delete cascade,
    constraint purchase_db_order_db_user_id_fk
        foreign key (order_user_id) references order_db (user_id)
            on update cascade on delete cascade,
    constraint purchase_db_user_db_id_fk
        foreign key (user_id) references user_db (id)
            on update cascade on delete cascade
);


